# chatbot brasileiro
Chatbot brasileiro que fala português criado com Deep Learning usando a técnica LSTM (Encoder/Decoder)

Criei apenas para fins de aprendizado. É possivel melhorar aspectos de perfomance e acuracia.  
Mas já dá um caldo :)

Python 3.5  
Keras 2.0  

# resources
Para rodar o código, é necessário baixar o modelo Word2Vec brasileiro  
https://github.com/felipeparpinelli/word2vec-pt-br
